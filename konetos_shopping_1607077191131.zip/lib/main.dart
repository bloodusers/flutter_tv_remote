import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/home/home.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primaryColor: Colors.teal[300],
          accentColor: Colors.teal[300],
          iconTheme: IconThemeData(color: Colors.black)),
      title: '',
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}
