import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class HorizontalList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120.0,
      child: ListView(
        scrollDirection: Axis.horizontal,
        itemExtent: 100,
        children: <Widget>[
          // ========= First Category  ===========
          Category(
            imageLocation: "assets/sale.svg",
            imageCaption: "PROPERTY FOR SALE",
            backColor: Colors.teal[300],
          ),
          Category(
            imageLocation: "assets/television.svg",
            imageCaption: "ELECTRONICS & HOME APPLIANCES",
            backColor: Colors.teal[100],
          ),

          Category(
            imageLocation: "assets/car.svg",
            imageCaption: "VEHICLES",
            backColor: Colors.lightBlue[300],
          ),
          // ========= Second Category  ===========
          Category(
            imageLocation: "assets/smartphone.svg",
            imageCaption: "MOBILES",
            backColor: Colors.amber[200],
          ),

          // ========= Fourth Category  ===========
        ],
      ),
    );
  }
}

class Category extends StatelessWidget {
  final String imageLocation;
  final String imageCaption;
  final Color backColor;

  const Category(
      {Key key, this.imageLocation, this.imageCaption, this.backColor})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(2.0),
      //Category UI
      child: InkWell(
        onTap: () {},
        child: Container(
          child: Column(
            children: [
              CircleAvatar(
                radius: 35,
                backgroundColor: backColor,
                child: SvgPicture.asset(
                  imageLocation,
                  width: 100.0,
                  height: 50.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5.0, left: 0),
                child: Text(
                  imageCaption,
                  style: TextStyle(fontSize: 10),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
