import 'package:flutter/material.dart';

import 'fav.dart';
import 'my_ads_content.dart';

class MyAds extends StatefulWidget {
  @override
  _MyAdsState createState() => _MyAdsState();
}

class _MyAdsState extends State<MyAds> {
  bool favTap = false;
  @override
  void initState() {
    super.initState();
    favTap = false;
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          bottom: TabBar(
            indicatorColor: Colors.teal[300],
            labelColor: Colors.teal[300],
            onTap: (i) {
              setState(() {
                if (i == 1) {
                  favTap = true;
                } else {
                  favTap = false;
                }
              });
            },
            tabs: [
              Tab(
                text: 'My Ads',
                icon: Icon(
                  Icons.bar_chart,
                  color: Colors.teal[300],
                ),
              ),
              Tab(
                text: 'Favorites',
                icon: favTap == true
                    ? Icon(
                        Icons.favorite,
                        color: Colors.teal[300],
                      )
                    : Icon(Icons.favorite_border),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            MyAdsContent(),
            Favorites(),
          ],
        ),
      ),
    );
  }
}
