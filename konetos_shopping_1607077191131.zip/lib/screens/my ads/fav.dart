import 'package:animations/animations.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/home/view_product.dart';

class Favorites extends StatefulWidget {
  @override
  _FavoritesState createState() => _FavoritesState();
}

class _FavoritesState extends State<Favorites> {
  List items = <String>[
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
    'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
  ];
  GlobalKey<ScaffoldState> _key = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Dismissible(
            background: ListTile(
              trailing: Icon(
                Icons.delete,
                color: Colors.black,
              ),
              tileColor: Colors.red,
            ),
            key: UniqueKey(),
            onDismissed: (direction) {
              setState(() {
                String deleted = items.removeAt(index);
                _key.currentState
                  ..removeCurrentSnackBar()
                  ..showSnackBar(SnackBar(
                    content: Text('removed from favorites'),
                    action: SnackBarAction(
                      onPressed: () {
                        setState(() {
                          items.insert(index, deleted);
                        });
                      },
                      label: 'UNDO',
                    ),
                  ));
              });
            },
            child: Container(
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
              child: ListTile(
                onTap: () {
                  Navigator.of(context).push(
                    PageRouteBuilder(
                      transitionDuration: Duration(milliseconds: 700),
                      pageBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secondaryAnimation) {
                        return ViewProduct(
                          url: items[index],
                        );
                      },
                      transitionsBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secondaryAnimation,
                          Widget child) {
                        return Align(
                          child: SharedAxisTransition(
                              transitionType: SharedAxisTransitionType.scaled,
                              secondaryAnimation: secondaryAnimation,
                              animation: animation,
                              child: child),
                        );
                      },
                    ),
                  );
                },
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(2)),
                leading: CachedNetworkImage(
                  imageUrl: items[index],
                  height: 70,
                  width: 70,
                ),
                title: Text('Dummy title'),
                subtitle: Text('dummy subtitle'),
                trailing: Icon(
                  Icons.favorite,
                  size: 40,
                  color: Colors.teal[300],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
