import 'dart:ui';

import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:konetos_shopping/screens/payment.dart';

class Packages extends StatefulWidget {
  @override
  _PackagesState createState() => _PackagesState();
}

class _PackagesState extends State<Packages> {
  bool checkVal = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            iconTheme: IconThemeData(color: Colors.white),
            leading: InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(Icons.close)),
            pinned: true,
            expandedHeight: 140,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Choose an option',
                textAlign: TextAlign.center,
                style: TextStyle(shadows: [
                  BoxShadow(
                    blurRadius: 2,
                    spreadRadius: 1,
                  ),
                ], color: Colors.white, fontSize: 22),
              ),
              background: SvgPicture.asset(
                'assets/tag.svg',
                fit: BoxFit.contain,
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate(
              [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Text(
                    'Post More Ads',
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Package available for 90 days'),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Divider(
                    color: Colors.black.withOpacity(0.8),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Text(
                    'Post More Ads',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '150 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 500',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 700',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '50 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 200',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 400',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Divider(
                    thickness: 8,
                    color: Colors.grey.withOpacity(0.8),
                  ),
                ),
                ListTile(
                  title: Text(
                    'Promoted Ad',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title:
                      Text('Get noticed with "PROMOTED" tag in a top position'),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Package available for 90 days'),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Divider(
                    color: Colors.black.withOpacity(0.8),
                  ),
                ),
                ListTile(
                  title: Text(
                    'Promoted Ads for 14 days',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Reach upto 6 times more buyers'),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '10 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 500',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 700',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '5 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 200',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 400',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Divider(
                    color: Colors.black,
                  ),
                ),
                ListTile(
                  title: Text(
                    'Promoted Ads for 7 days',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Reach upto 6 times more buyers'),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '10 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 500',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 700',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '5 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 200',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 400',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Divider(
                    thickness: 8,
                    color: Colors.grey.withOpacity(0.8),
                  ),
                ),
                ListTile(
                  title: Text(
                    'Boost to Top',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Back on top like a new ad'),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('package available for 90 days'),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Divider(
                    color: Colors.black,
                  ),
                ),
                ListTile(
                  title: Text(
                    'Boost to Top',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.black,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                ListTile(
                  leading: SvgPicture.asset(
                    'assets/tick.svg',
                    height: 20,
                    width: 20,
                  ),
                  title: Text('Reach upto 2 times more buyers'),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '10 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 500',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 700',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ClipPath(
                      clipper: MultipleRoundedCurveClipper(),
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                          color: Colors.teal[500],
                        ),
                        height: 175,
                        width: 175,
                        child: Column(
                          children: [
                            ListTile(
                              leading: Theme(
                                data: Theme.of(context).copyWith(
                                    unselectedWidgetColor: Colors.white),
                                child: Checkbox(
                                  checkColor: Colors.white,
                                  value: checkVal,
                                  onChanged: (v) {
                                    setState(() {
                                      checkVal = v;
                                    });
                                  },
                                ),
                              ),
                              title: Text(
                                '5 ADS',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Divider(
                                color: Colors.white,
                              ),
                            ),
                            ListTile(
                              leading: ClipPath(
                                clipper: StarClipper(8),
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.yellow,
                                  child: Center(child: Text('-27%')),
                                ),
                              ),
                              title: Text(
                                'R 200',
                                style: TextStyle(color: Colors.white),
                              ),
                              trailing: Text(''),
                              subtitle: Text(
                                'R 400',
                                style: TextStyle(
                                    decoration: TextDecoration.lineThrough,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                RaisedButton(
                  color: Colors.teal[300],
                  child: Text('Next', style: TextStyle(color: Colors.white)),
                  onPressed: () {
                    Navigator.of(context).push(
                      PageRouteBuilder(
                        transitionDuration: Duration(milliseconds: 700),
                        pageBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secondaryAnimation) {
                          return PaymentMethods();
                        },
                        transitionsBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secondaryAnimation,
                            Widget child) {
                          return Align(
                            child: SharedAxisTransition(
                                transitionType: SharedAxisTransitionType.scaled,
                                secondaryAnimation: secondaryAnimation,
                                animation: animation,
                                child: child),
                          );
                        },
                      ),
                    );
                  },
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
