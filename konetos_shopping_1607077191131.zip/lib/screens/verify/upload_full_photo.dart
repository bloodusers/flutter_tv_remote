import 'package:flutter/material.dart';

class UploadFullPhoto extends StatefulWidget {
  @override
  _UploadFullPhotoState createState() => _UploadFullPhotoState();
}

class _UploadFullPhotoState extends State<UploadFullPhoto> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 400,
          decoration: BoxDecoration(
            color: Colors.grey[300],
          ),
          child: Center(
            child: RaisedButton.icon(
              label: Text('upload your photo'),
              icon: Icon(Icons.camera_alt),
              onPressed: () {},
            ),
          ),
        ),
      ],
    );
  }
}
