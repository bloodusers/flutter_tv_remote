import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/sell/sell_content.dart';

class VerifyWithGovDocs extends StatefulWidget {
  @override
  _VerifyWithGovDocsState createState() => _VerifyWithGovDocsState();
}

class _VerifyWithGovDocsState extends State<VerifyWithGovDocs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(90),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          iconTheme: IconThemeData(color: Colors.black),
          backgroundColor: Colors.white,
          flexibleSpace: Padding(
            padding: const EdgeInsets.only(top: 38.0),
            child: Center(
              child: Text(
                'Verify With government approved docs',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),
              ),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 28.0),
              child: Container(
                height: 400,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                ),
                child: Center(
                  child: RaisedButton.icon(
                    label: Text('Choose Files'),
                    icon: Icon(Icons.camera_alt),
                    onPressed: () {},
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Verify',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => SellContent()));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
