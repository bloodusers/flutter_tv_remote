import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/pick%20images/pick_images.dart';

class Houses extends StatefulWidget {
  @override
  _HousesState createState() => _HousesState();
}

class _HousesState extends State<Houses> {
  TextEditingController bathroomController = TextEditingController();

  TextEditingController bedroomController = TextEditingController();
  TextEditingController areaUnitController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController areaController = TextEditingController();
  TextEditingController descController = TextEditingController();

  bool isNo = false;
  bool isYes = false;

  showBedroomDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Houses > Bedrooms'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('1'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bedroomController.text = '1';
                });
              },
            ),
            ListTile(
              title: Text('2'),
              onTap: () {
                setState(() {
                  bedroomController.text = '2';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bedroomController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bedroomController.text = '4';
                });
              },
            ),
            ListTile(
              title: Text('5'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bedroomController.text = '5';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showBathroomDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Houses > Bathrooms'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('1'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bathroomController.text = '1';
                });
              },
            ),
            ListTile(
              title: Text('2'),
              onTap: () {
                setState(() {
                  bathroomController.text = '2';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bathroomController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bathroomController.text = '4';
                });
              },
            ),
            ListTile(
              title: Text('5'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  bathroomController.text = '5';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showAreaUnitDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Houses > Area Unit'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Square Feet'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = 'Square Feet';
                });
              },
            ),
            ListTile(
              title: Text('1'),
              onTap: () {
                setState(() {
                  areaUnitController.text = '1';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('2'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '2';
                });
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '4';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showBedroomDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: bedroomController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Bedrooms*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showBathroomDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: bathroomController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Bathrooms*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showAreaUnitDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: areaUnitController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Area Unit*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: areaController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Area*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            ListTile(
              title: Text(
                'Furnished*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isNo = !isNo;
                      if (isYes == true) {
                        isYes = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'No',
                      style: TextStyle(
                          color: isNo == true ? Colors.white : Colors.black),
                    )),
                    decoration: isNo == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isYes = !isYes;
                      if (isNo == true) {
                        isNo = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Yes',
                      style: TextStyle(
                          color: isYes == true ? Colors.white : Colors.black),
                    )),
                    decoration: isYes == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => PickImages()));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
