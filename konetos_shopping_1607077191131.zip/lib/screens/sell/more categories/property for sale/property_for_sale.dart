import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/property%20for%20sale/portions_and_floors.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/property%20for%20sale/shops.dart';

import 'apartments_and_flats.dart';
import 'houses.dart';
import 'land_and_plots.dart';

class PropertyForSale extends StatefulWidget {
  @override
  _PropertyForSaleState createState() => _PropertyForSaleState();
}

class _PropertyForSaleState extends State<PropertyForSale> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Property for Sale',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: ListView(
        children: [
          SizedBox(
            height: 20,
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => LandAndPlots()));
              },
              title: Text('Land & Plots'),
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Houses()));
              },
              title: Text('Houses'),
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => ApartmentsAndFlats()));
              },
              title: Text('Apartment & Flats'),
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Shops()));
              },
              title: Text('Shops - Offices - Commercial Space'),
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(color: Colors.grey.withOpacity(0.3)))),
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => PortionsAndFloors()));
              },
              title: Text('Portion & Floors'),
            ),
          ),
        ],
      ),
    );
  }
}
