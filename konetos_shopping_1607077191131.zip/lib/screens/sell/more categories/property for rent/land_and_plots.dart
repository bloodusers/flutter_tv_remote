import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/pick%20images/pick_images.dart';

class LandAndPlots extends StatefulWidget {
  @override
  _LandAndPlotsState createState() => _LandAndPlotsState();
}

class _LandAndPlotsState extends State<LandAndPlots> {
  TextEditingController typeController = TextEditingController();
  TextEditingController areaUnitController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController areaController = TextEditingController();
  TextEditingController descController = TextEditingController();

  showTypeDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Land & Plots > Type'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Agriculture Land'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  typeController.text = 'Agriculture Land';
                });
              },
            ),
            ListTile(
              title: Text('dummy text'),
              onTap: () {
                setState(() {
                  typeController.text = 'dummy text';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  typeController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  typeController.text = '4';
                });
              },
            ),
            ListTile(
              title: Text('5'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  typeController.text = '5';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showAreaUnitDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Land & Plots > Area Unit'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Square Feet'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = 'Square Feet';
                });
              },
            ),
            ListTile(
              title: Text('1'),
              onTap: () {
                setState(() {
                  areaUnitController.text = '1';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('2'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '2';
                });
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  areaUnitController.text = '4';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showTypeDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: typeController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Type*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showAreaUnitDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: areaUnitController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Area Unit*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: areaController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Area*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => PickImages()));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
