import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/animals/animals.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/bikes/bikes.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/books,sports%20&%20hobbies/books_sports_hobbies.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/electronics%20&%20home%20appliances/electronics_and_home_appliances.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/jobs/jobs.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/kids/kids.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/mobiles/mobiles.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/property%20for%20rent/property_for_rent.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/services/services.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/vehicles/vehicles.dart';

import 'business industrial and agriculture/business_industrial_agriculture.dart';
import 'fashion & beauty/fashion_and_beauty.dart';
import 'furniture & home decor/furniture_and_home_decor.dart';
import 'property for sale/property_for_sale.dart';

class MoreCategories extends StatefulWidget {
  @override
  _MoreCategoriesState createState() => _MoreCategoriesState();
}

class _MoreCategoriesState extends State<MoreCategories> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        elevation: 5.0,
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.close),
        ),
        title: Text(
          'More Categories',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: ListView(
        children: [
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Mobiles()));
              },
              leading: SvgPicture.asset(
                'assets/smartphone.svg',
                height: 30,
              ),
              title: Text('Mobiles', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Vehicles()));
              },
              leading: SvgPicture.asset(
                'assets/car.svg',
                height: 30,
              ),
              title: Text('Vehicles', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => PropertyForSale()));
              },
              leading: SvgPicture.asset(
                'assets/sale.svg',
                height: 30,
              ),
              title: Text('Property for sale',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => PropertyForRent()));
              },
              leading: SvgPicture.asset(
                'assets/rent.svg',
                height: 30,
              ),
              title: Text('Property for rent',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => ElectronicsAndHomeAppliances()));
              },
              leading: SvgPicture.asset(
                'assets/television.svg',
                height: 30,
              ),
              title: Text('Electronics and Home Appliances',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Bikes()));
              },
              leading: Icon(
                Icons.directions_bike,
                size: 30,
                color: Colors.black,
              ),
              title: Text('Bikes', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => BusinessIndustrialAndAgriculture()));
              },
              leading: Icon(
                Icons.business,
                size: 30,
                color: Colors.black,
              ),
              title: Text('Business, Industrial & Agriculture',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => ServicesCategory()));
              },
              leading: Icon(
                Icons.miscellaneous_services,
                size: 30,
                color: Colors.black,
              ),
              title: Text('Services', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Jobs()));
              },
              leading: Icon(
                Icons.business_center_outlined,
                size: 30,
                color: Colors.black,
              ),
              title: Text('Jobs', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Animals()));
              },
              leading: SvgPicture.asset(
                'assets/footprint.svg',
                height: 30,
              ),
              title: Text('Animals', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => FurnitureAndHomeDecor()));
              },
              leading: SvgPicture.asset(
                'assets/furniture.svg',
                height: 30,
              ),
              title: Text('Furniture & Home Decoration',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => FashionAndBeauty()));
              },
              leading: SvgPicture.asset(
                'assets/shirt.svg',
                height: 30,
              ),
              title: Text('Fashion & Beauty',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => BookSportsAndHobbies()));
              },
              leading: SvgPicture.asset(
                'assets/study.svg',
                height: 30,
              ),
              title: Text('Books sports & Hobbies',
                  style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            elevation: 2.5,
            child: ListTile(
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => Kids()));
              },
              leading: SvgPicture.asset(
                'assets/baby-boy.svg',
                height: 30,
              ),
              title: Text('Kids', style: TextStyle(color: Colors.black)),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ),
        ],
      ),
    );
  }
}
