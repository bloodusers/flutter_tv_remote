import 'package:flutter/material.dart';

class CarsOnInstallment extends StatefulWidget {
  @override
  _CarsOnInstallmentState createState() => _CarsOnInstallmentState();
}

class _CarsOnInstallmentState extends State<CarsOnInstallment> {
  TextEditingController makeController = TextEditingController();
  TextEditingController downPaymentController = TextEditingController();
  TextEditingController monthlyIntallmentController = TextEditingController();
  TextEditingController registerController = TextEditingController();
  TextEditingController installmentPlanController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController yearController = TextEditingController();
  TextEditingController descController = TextEditingController();
  TextEditingController kmsController = TextEditingController();
  bool isNew = false;
  bool isOld = false;
  bool isAuto = false;
  bool isManual = false;
  bool isNotRegistered = false;
  bool isRegistered = false;
  bool isBank = false;
  bool isNotBank = false;
  bool isFinance = false;
  bool isLeasing = false;

  showTypeDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Cars > make'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Audi'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'Audi';
                });
              },
            ),
            ListTile(
              title: Text('dummy text'),
              onTap: () {
                setState(() {
                  makeController.text = 'dummy text';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('BMW'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'BMW';
                });
              },
            ),
            ListTile(
              title: Text('Other Brands'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'Other Brands';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showsInstallmentPlanDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Cars > Installment Plan'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Flexible'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  installmentPlanController.text = 'Flexible';
                });
              },
            ),
            ListTile(
              title: Text('1 year'),
              onTap: () {
                setState(() {
                  installmentPlanController.text = '1 year';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('2'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  installmentPlanController.text = '2';
                });
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  installmentPlanController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  installmentPlanController.text = '4';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showTypeDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: makeController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Make*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: yearController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Year*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Condition*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isNew = !isNew;
                      if (isOld == true) {
                        isOld = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'New',
                      style: TextStyle(
                          color: isNew == true ? Colors.white : Colors.black),
                    )),
                    decoration: isNew == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isOld = !isOld;
                      if (isNew == true) {
                        isNew = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Old',
                      style: TextStyle(
                          color: isOld == true ? Colors.white : Colors.black),
                    )),
                    decoration: isOld == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Transmission*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isAuto = !isAuto;
                      if (isManual == true) {
                        isManual = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Auto',
                      style: TextStyle(
                          color: isAuto == true ? Colors.white : Colors.black),
                    )),
                    decoration: isAuto == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isManual = !isManual;
                      if (isAuto == true) {
                        isAuto = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Manual',
                      style: TextStyle(
                          color:
                              isManual == true ? Colors.white : Colors.black),
                    )),
                    decoration: isManual == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Registered*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isRegistered = !isRegistered;
                      if (isNotRegistered == true) {
                        isNotRegistered = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Yes',
                      style: TextStyle(
                          color: isRegistered == true
                              ? Colors.white
                              : Colors.black),
                    )),
                    decoration: isRegistered == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isNotRegistered = !isNotRegistered;
                      if (isRegistered == true) {
                        isRegistered = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'No',
                      style: TextStyle(
                          color: isNotRegistered == true
                              ? Colors.white
                              : Colors.black),
                    )),
                    decoration: isNotRegistered == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Financer Type*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isBank = !isBank;
                      if (isNotBank == true) {
                        isNotBank = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Bank',
                      style: TextStyle(
                          color: isBank == true ? Colors.white : Colors.black),
                    )),
                    decoration: isBank == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isNotBank = !isNotBank;
                      if (isBank == true) {
                        isBank = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Non Banking',
                      style: TextStyle(
                          color:
                              isNotBank == true ? Colors.white : Colors.black),
                    )),
                    decoration: isNotBank == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Transaction Type*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isFinance = !isFinance;
                      if (isLeasing == true) {
                        isLeasing = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Financing',
                      style: TextStyle(
                          color:
                              isFinance == true ? Colors.white : Colors.black),
                    )),
                    decoration: isFinance == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isLeasing = !isLeasing;
                      if (isFinance == true) {
                        isFinance = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Leasing',
                      style: TextStyle(
                          color:
                              isLeasing == true ? Colors.white : Colors.black),
                    )),
                    decoration: isLeasing == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showsInstallmentPlanDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: installmentPlanController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Installment Plan*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: downPaymentController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Down Payment (\$)*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: monthlyIntallmentController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Monthly Installment (\$)*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
