import 'package:flutter/material.dart';

class OtherVehicles extends StatefulWidget {
  @override
  _OtherVehiclesState createState() => _OtherVehiclesState();
}

class _OtherVehiclesState extends State<OtherVehicles> {
  TextEditingController titleController = TextEditingController();
  TextEditingController descController = TextEditingController();
  bool isNew = false;
  bool isOld = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            ListTile(
              title: Text(
                'Condition*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isNew = !isNew;
                      if (isOld == true) {
                        isOld = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'New',
                      style: TextStyle(
                          color: isNew == true ? Colors.white : Colors.black),
                    )),
                    decoration: isNew == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isOld = !isOld;
                      if (isNew == true) {
                        isNew = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Old',
                      style: TextStyle(
                          color: isOld == true ? Colors.white : Colors.black),
                    )),
                    decoration: isOld == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
