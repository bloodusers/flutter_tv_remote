import 'package:flutter/material.dart';

class Cars extends StatefulWidget {
  @override
  _CarsState createState() => _CarsState();
}

class _CarsState extends State<Cars> {
  TextEditingController makeController = TextEditingController();
  TextEditingController registerController = TextEditingController();
  TextEditingController fuelController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController yearController = TextEditingController();
  TextEditingController descController = TextEditingController();
  TextEditingController kmsController = TextEditingController();
  bool isNew = false;
  bool isOld = false;

  showTypeDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Cars > make'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Audi'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'Audi';
                });
              },
            ),
            ListTile(
              title: Text('dummy text'),
              onTap: () {
                setState(() {
                  makeController.text = 'dummy text';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('BMW'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'BMW';
                });
              },
            ),
            ListTile(
              title: Text('Other Brands'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  makeController.text = 'Other Brands';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showFuelDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Cars > Fuel'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('CNG'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  fuelController.text = 'CNG';
                });
              },
            ),
            ListTile(
              title: Text('dummy text'),
              onTap: () {
                setState(() {
                  fuelController.text = 'dummy text';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  fuelController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  fuelController.text = '4';
                });
              },
            ),
            ListTile(
              title: Text('5'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  fuelController.text = '5';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showRegisterTypeDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Cars > Registered in'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('City1'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  registerController.text = 'City1';
                });
              },
            ),
            ListTile(
              title: Text('City2'),
              onTap: () {
                setState(() {
                  registerController.text = 'City2';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  registerController.text = '3';
                });
              },
            ),
            ListTile(
              title: Text('4'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  registerController.text = '4';
                });
              },
            ),
            ListTile(
              title: Text('Unregistered'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  registerController.text = 'Unregistered';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showTypeDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: makeController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Make*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: yearController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Year*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: kmsController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'KMs driven*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showFuelDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: fuelController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Fuel*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showRegisterTypeDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: registerController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Registered in',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ListTile(
              title: Text(
                'Condition*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isNew = !isNew;
                      if (isOld == true) {
                        isOld = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'New',
                      style: TextStyle(
                          color: isNew == true ? Colors.white : Colors.black),
                    )),
                    decoration: isNew == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isOld = !isOld;
                      if (isNew == true) {
                        isNew = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Old',
                      style: TextStyle(
                          color: isOld == true ? Colors.white : Colors.black),
                    )),
                    decoration: isOld == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
