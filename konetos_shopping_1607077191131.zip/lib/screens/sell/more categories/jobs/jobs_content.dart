import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/pick%20images/pick_images.dart';

class JobsContent extends StatefulWidget {
  @override
  _JobsContentState createState() => _JobsContentState();
}

class _JobsContentState extends State<JobsContent> {
  TextEditingController titleController = TextEditingController();
  TextEditingController salFromController = TextEditingController();
  TextEditingController positionController = TextEditingController();
  TextEditingController salController = TextEditingController();
  TextEditingController descController = TextEditingController();
  bool isCV = false;
  bool isOffer = false;

  showTypeDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Position > Type'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Contract'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  positionController.text = 'Contract';
                });
              },
            ),
            ListTile(
              title: Text('Full Time'),
              onTap: () {
                setState(() {
                  positionController.text = 'Full Time';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('Part Time'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  positionController.text = 'Part Time';
                });
              },
            ),
            ListTile(
              title: Text('Temporary'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  positionController.text = 'Temporary';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  showSalDialog(BuildContext context) {
    AlertDialog alertDialog = AlertDialog(
      title: Text('Salary period'),
      actions: [
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(color: Colors.teal),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )
      ],
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('Hourly'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  salController.text = 'Hourly';
                });
              },
            ),
            ListTile(
              title: Text('Weekly'),
              onTap: () {
                setState(() {
                  salController.text = 'Weekly';
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('Monthly'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  salController.text = 'Monthly';
                });
              },
            ),
            ListTile(
              title: Text('Yearly'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  salController.text = 'Yearly';
                });
              },
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return alertDialog;
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'Include some details',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            ListTile(
              title: Text(
                'Ad Type*',
                style:
                    TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isCV = !isCV;
                      if (isOffer == true) {
                        isOffer = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'Job offer',
                      style: TextStyle(
                          color: isCV == true ? Colors.white : Colors.black),
                    )),
                    decoration: isCV == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isOffer = !isOffer;
                      if (isCV == true) {
                        isCV = false;
                      }
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    child: Center(
                        child: Text(
                      'CVs & Resumes',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: isOffer == true ? Colors.white : Colors.black),
                    )),
                    decoration: isOffer == true
                        ? BoxDecoration(
                            color: Colors.teal[300].withOpacity(0.8),
                            border:
                                Border.all(width: 1.5, color: Colors.teal[300]),
                            borderRadius: BorderRadius.circular(8))
                        : BoxDecoration(
                            border: Border.all(width: 1.5),
                            borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showTypeDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: positionController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Position Type*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: GestureDetector(
                onTap: () {
                  showSalDialog(context);
                },
                child: AbsorbPointer(
                  child: TextFormField(
                    controller: salController,
                    cursorColor: Colors.teal[300],
                    decoration: InputDecoration(
                      hintText: 'Salary Period*',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                keyboardType: TextInputType.number,
                controller: salFromController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Salary from*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: titleController,
                cursorColor: Colors.teal[300],
                decoration: InputDecoration(
                  hintText: 'Title*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextFormField(
                controller: descController,
                cursorColor: Colors.teal[300],
                maxLines: 5,
                decoration: InputDecoration.collapsed(
                  hintText: 'Description*',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 300,
                color: Colors.white,
                child: RaisedButton(
                  color: Colors.teal[300],
                  child: Text(
                    'Next',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => PickImages()));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
