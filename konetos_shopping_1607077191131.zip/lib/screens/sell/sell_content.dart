import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/electronics%20&%20home%20appliances/electronics_and_home_appliances.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/more_categories.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/property%20for%20rent/property_for_rent.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/property%20for%20sale/property_for_sale.dart';
import 'package:konetos_shopping/screens/sell/more%20categories/vehicles/vehicles.dart';

import 'more categories/mobiles/mobiles.dart';

class SellContent extends StatefulWidget {
  @override
  _SellContentState createState() => _SellContentState();
}

class _SellContentState extends State<SellContent> {
  bool moreCategories = false;
  bool rent = false;
  bool mobiles = false;
  bool vehicles = false;
  bool electronics = false;
  bool sale = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.close,
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 5.0,
          title: Text(
            'What are you offering?',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: AnimationLimiter(
        child: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
            children: List.generate(
              6,
              (int index) {
                return AnimationConfiguration.staggeredGrid(
                  position: index,
                  duration: const Duration(milliseconds: 600),
                  columnCount: 1,
                  child: ScaleAnimation(
                    child: FadeInAnimation(
                      child: GestureDetector(
                        onTap: () {
                          if (index == 5 && moreCategories == true) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => MoreCategories()));
                          }
                          if (index == 0 && sale == true) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => PropertyForSale()));
                          }
                          if (index == 1 && vehicles == true) {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Vehicles()));
                          }
                          if (index == 2 && electronics == true) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) =>
                                        ElectronicsAndHomeAppliances()));
                          }
                          if (index == 3 && mobiles == true) {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Mobiles()));
                          }
                          if (index == 4 && rent == true) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => PropertyForRent()));
                          }
                        },
                        child: GridTile(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(),
                            ),
                            child: gridContent(index),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget gridContent(int index) {
    if (index == 0) {
      setState(() {
        sale = true;
      });
      return Stack(children: [
        Center(
          child: SvgPicture.asset(
            'assets/sale.svg',
            height: 100,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'Property for sale',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
    if (index == 1) {
      setState(() {
        vehicles = true;
      });
      return Stack(children: [
        Center(
          child: SvgPicture.asset(
            'assets/car.svg',
            height: 100,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'Vehicles',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
    if (index == 2) {
      setState(() {
        electronics = true;
      });
      return Stack(children: [
        Center(
          child: SvgPicture.asset(
            'assets/television.svg',
            height: 100,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'Electronics and Home appliances',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
    if (index == 3) {
      setState(() {
        mobiles = true;
      });
      return Stack(children: [
        Center(
          child: SvgPicture.asset(
            'assets/smartphone.svg',
            height: 100,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'Mobiles',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
    if (index == 4) {
      setState(() {
        rent = true;
      });
      return Stack(children: [
        Center(
          child: SvgPicture.asset(
            'assets/rent.svg',
            height: 100,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'Property for rent',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
    if (index == 5) {
      setState(() {
        moreCategories = true;
      });
      return Stack(children: [
        Center(
            child: Icon(
          Icons.category,
          size: 60,
        )),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              'More Categories',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ]);
    }
  }
}
