import 'package:flutter/material.dart';
import 'package:animations/animations.dart';
import 'package:konetos_shopping/screens/packages.dart';
import 'package:konetos_shopping/screens/verify/upload_full_photo.dart';
import 'package:konetos_shopping/screens/verify/verify_with_gov_docs.dart';
import 'package:konetos_shopping/screens/verify/verify_with_idcard.dart';
import 'package:konetos_shopping/screens/verify/verify_with_passport.dart';

class Sell extends StatefulWidget {
  @override
  _SellState createState() => _SellState();
}

class _SellState extends State<Sell> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100),
          child: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            flexibleSpace: Center(
              child: Text(
                'To start selling first you have to verify yourself',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black, fontSize: 20),
              ),
            ),
          ),
        ),
        body: SafeArea(
          child: Scrollbar(
            radius: Radius.circular(30),
            thickness: 12,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Text(
                      'Verification Methods',
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                  OpenContainer(
                    transitionDuration: Duration(milliseconds: 500),
                    closedBuilder: (ctx, action) {
                      return ListTile(
                        title: Text('Verify by Id Card'),
                        trailing: Icon(Icons.keyboard_arrow_down),
                      );
                    },
                    openBuilder: (ctx, action) {
                      return VerifyByIdCard();
                    },
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  OpenContainer(
                    transitionDuration: Duration(milliseconds: 500),
                    closedBuilder: (ctx, action) {
                      return ListTile(
                        title: Text('Verify by International Passport'),
                        trailing: Icon(Icons.keyboard_arrow_down),
                      );
                    },
                    openBuilder: (ctx, action) {
                      return VerifyWithPassport();
                    },
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  OpenContainer(
                    transitionDuration: Duration(milliseconds: 500),
                    closedBuilder: (ctx, action) {
                      return ListTile(
                        title: Text('Verify by Government Approved documents'),
                        trailing: Icon(Icons.keyboard_arrow_down),
                      );
                    },
                    openBuilder: (ctx, action) {
                      return VerifyWithGovDocs();
                    },
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  UploadFullPhoto(),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Text(
                      'Packages',
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                  OpenContainer(
                    transitionDuration: Duration(milliseconds: 200),
                    closedBuilder: (ctx, action) {
                      return ListTile(
                        title: Text('View Packages'),
                        trailing: Icon(Icons.keyboard_arrow_down),
                      );
                    },
                    openBuilder: (ctx, action) {
                      return Packages();
                    },
                  ),
                  SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ));
  }
}
