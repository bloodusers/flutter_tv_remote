import 'package:cached_network_image/cached_network_image.dart';
import 'package:clippy_flutter/label.dart';
import 'package:flutter/material.dart';
import 'package:konetos_shopping/screens/home/buy_product.dart';
import 'package:konetos_shopping/screens/home/view_product.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  bool _showButtons = false;
  bool fav = false;
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              childAspectRatio: 1,
              physics: ClampingScrollPhysics(),
              shrinkWrap: true,
              padding: const EdgeInsets.all(2.0),
              mainAxisSpacing: 10.0,
              crossAxisSpacing: 10.0,
              children: <String>[
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
                'https://images.pexels.com/photos/1682519/pexels-photo-1682519.jpeg',
              ].map((String url) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _showButtons = !_showButtons;
                    });
                  },
                  child: GridTile(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey, width: 4),
                      ),
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Hero(
                              transitionOnUserGestures: true,
                              tag: new Text('hero1'),
                              child: CachedNetworkImage(
                                imageUrl: url,
                                placeholder: (context, url) => Center(
                                  child: CircularProgressIndicator(),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(bottom: 1.0, left: 5),
                              child: Text(
                                  'Haier laptop\nprice: \$200\nlocation: Pakistan'),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Container(
                                height: 15,
                                width: 70,
                                child: Center(
                                  child: Text(
                                    'SellerName',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 10),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Label(
                                triangleHeight: 10,
                                edge: Edge.RIGHT,
                                child: Container(
                                  color: Colors.yellow,
                                  width: 60,
                                  height: 15,
                                  child: Text(
                                    'Promoted',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 10),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topRight,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    fav = !fav;
                                  });
                                },
                                child: CircleAvatar(
                                  radius: 15,
                                  backgroundColor: Colors.white,
                                  child: fav == false
                                      ? Icon(
                                          Icons.favorite_outline,
                                          color: Colors.teal[300],
                                        )
                                      : Icon(
                                          Icons.favorite,
                                          color: Colors.teal[300],
                                        ),
                                ),
                              ),
                            ),
                          ),
                          _showButtons
                              ? GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _showButtons = !_showButtons;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      color:
                                          Colors.transparent.withOpacity(0.4),
                                    ),
                                  ),
                                )
                              : Text(''),
                          _showButtons
                              ? Positioned(
                                  bottom: 70,
                                  left: 5,
                                  child: Row(
                                    children: [
                                      Container(
                                        height: 20,
                                        width: 70,
                                        child: RaisedButton(
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          color: Colors.teal[300],
                                          child: Text(
                                            'View',
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          onPressed: () {
                                            Navigator.of(context).push(
                                              PageRouteBuilder(
                                                transitionDuration:
                                                    Duration(milliseconds: 600),
                                                pageBuilder: (BuildContext
                                                        context,
                                                    Animation<double> animation,
                                                    Animation<double>
                                                        secondaryAnimation) {
                                                  return ViewProduct(url: url);
                                                },
                                                transitionsBuilder:
                                                    (BuildContext context,
                                                        Animation<double>
                                                            animation,
                                                        Animation<double>
                                                            secondaryAnimation,
                                                        Widget child) {
                                                  return Align(
                                                    child: FadeTransition(
                                                        opacity: animation,
                                                        child: child),
                                                  );
                                                },
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                      Container(
                                        height: 20,
                                        width: 70,
                                        child: RaisedButton(
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          color: Colors.teal[300],
                                          child: Text(
                                            'Buy',
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (_) => BuyProduct(
                                                          url: url,
                                                        )));
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : Text(''),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          SizedBox(
            height: 40,
          ),
        ],
      ),
    );
  }
}
