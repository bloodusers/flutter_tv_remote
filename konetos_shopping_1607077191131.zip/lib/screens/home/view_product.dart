import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ViewProduct extends StatefulWidget {
  String url = '';
  ViewProduct({this.url});
  @override
  _ViewProductState createState() => _ViewProductState();
}

class _ViewProductState extends State<ViewProduct> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Hero(
          transitionOnUserGestures: true,
          tag: new Text('hero1'),
          child: CachedNetworkImage(
            imageUrl: widget.url,
            placeholder: (context, url) => Center(
              child: CircularProgressIndicator(),
            ),
          ),
        ),
      ),
    );
  }
}
