import 'package:flutter/material.dart';
import 'package:flutter_snake_navigationbar/flutter_snake_navigationbar.dart';
import 'package:konetos_shopping/screens/my%20ads/my_ads.dart';
import 'package:konetos_shopping/screens/sell/sell.dart';

import 'home_content.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  static List<Widget> widgetOptions = <Widget>[
    HomeContent(),
    Sell(),
    MyAds(),
  ];
  ShapeBorder bottomBarShape = RoundedRectangleBorder(
    borderRadius: BorderRadius.only(
        topRight: Radius.circular(25), topLeft: Radius.circular(25)),
  );
  SnakeBarBehaviour snakeBarStyle = SnakeBarBehaviour.floating;
  EdgeInsets padding = EdgeInsets.only(bottom: 10);
  int _selectedItemPosition = 0;
  SnakeShape snakeShape = SnakeShape.rectangle;
  bool showSelectedLabels = true;
  bool showUnselectedLabels = true;

  Color selectedColor = Colors.white;
  Gradient selectedGradient =
      LinearGradient(colors: [Colors.red, Colors.amber]);

  Color unselectedColor = Colors.black;
  Gradient unselectedGradient =
      LinearGradient(colors: [Colors.red, Colors.blueGrey]);

  Color containerColor;
  List<Color> containerColors = [
    Color(0xFFFDE1D7),
    Color(0xFFE4EDF5),
    Color(0xFFF4E4CE),
    Color(0xFFE7EEED),
  ];
  bool icon1 = true;
  bool icon = false;
  bool icon2 = false;
  @override
  void initState() {
    super.initState();
    icon1 = true;
    icon2 = false;
    icon = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF75B7E1),
      extendBody: true,
      bottomNavigationBar: SnakeNavigationBar.color(
        backgroundColor: Colors.white,
        behaviour: snakeBarStyle,
        snakeShape: snakeShape,
        shape: bottomBarShape,
        padding: padding,
        snakeViewColor: selectedColor,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.black,
        showUnselectedLabels: showUnselectedLabels,
        showSelectedLabels: showSelectedLabels,
        currentIndex: _selectedItemPosition,
        onTap: (index) => setState(() {
          _selectedItemPosition = index;
          if (index != 0) {
            icon1 = false;
          } else {
            icon1 = true;
          }
          if (index == 1) {
            icon = true;
          } else {
            icon = false;
          }

          if (index == 2) {
            icon2 = true;
          } else {
            icon2 = false;
          }
        }),
        items: [
          BottomNavigationBarItem(
              icon: icon1 == true
                  ? Icon(
                      Icons.home,
                      size: 30,
                    )
                  : Icon(Icons.home_outlined),
              label: 'Home'),
          BottomNavigationBarItem(
              icon: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(32),
                  gradient: icon == true
                      ? LinearGradient(
                          colors: [
                            Colors.greenAccent,
                            Colors.teal,
                          ],
                        )
                      : LinearGradient(
                          colors: [
                            Colors.black26,
                            Colors.black,
                          ],
                        ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 5),
                      borderRadius: BorderRadius.circular(32),
                    ),
                    child: Icon(Icons.add, color: Colors.white),
                  ),
                ),
              ),
              label: 'Sell'),
          BottomNavigationBarItem(
              icon: icon2 == true
                  ? Icon(
                      Icons.favorite,
                      size: 30,
                    )
                  : Icon(Icons.favorite_outline),
              label: 'My Ads'),
        ],
      ),
      body: widgetOptions.elementAt(_selectedItemPosition),
    );
  }
}
