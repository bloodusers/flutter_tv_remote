package com.example.konetos_shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
